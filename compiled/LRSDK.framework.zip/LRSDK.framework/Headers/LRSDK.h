//
//  LRSDK.h
//
//  Copyright © 2016 LoginRadius Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LRSDK.
FOUNDATION_EXPORT double LRSDKVersionNumber;

//! Project version string for LRSDK.
FOUNDATION_EXPORT const unsigned char LRSDKVersionString[];

#import <LRSDK/LoginRadiusSDK.h>
#import <LRSDK/LoginRadiusREST.h>
#import <LRSDK/LRErrorCode.h>
#import <LRSDK/LRErrors.h>
